"""
University of Liege
ELEN0062 - Introduction to machine learning
Project 1 - Classification algorithms
"""
#! /usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
from data import make_dataset2
from data import make_dataset1
from plot import plot_boundary
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.base import BaseEstimator, ClassifierMixin



class LinearDiscriminantAnalysis(BaseEstimator, ClassifierMixin):

    cov_matrix = np.array([])
    classes = []
    mu = []
    pi = []


    def fit(self, X, y):
        """Fit a linear discriminant analysis model using the training set
        (X, y).

        Parameters
        ----------
        X : array-like, shape = [n_samples, n_features]
            The training input samples.

        y : array-like, shape = [n_samples]
            The target values.

        Returns
        -------
        self : object
            Returns self.
        """
        # Input validation
        X = np.asarray(X, dtype=np.float)
        if X.ndim != 2:
            raise ValueError("X must be 2 dimensional")

        y = np.asarray(y)
        if y.shape[0] != X.shape[0]:
            raise ValueError("The number of samples differs between X and y")

        data = np.hstack((X,np.asarray([y]).T))

        #Dictionary will contain the classes as key and a tuple (pi,mu) as value
        dictionary = {}
        #Compute mu and pi
        for sample in data:
            if sample[-1] in dictionary:
                #Update the value
                dictionary[sample[-1]][0] += 1
                dictionary[sample[-1]][1] = np.add(dictionary[sample[-1]][1],sample[0:-1])
            else:
                #Create a new entry in the dictionary
                dictionary[sample[-1]] = [1 , np.array(sample[0:-1])]


        for key in dictionary:
            #Normalize the value of pi and mu
            dictionary[key][1] = np.divide(dictionary[key][1],dictionary[key][0])
            dictionary[key][0] = dictionary[key][0]/y.shape[0]
        
        #sort the dictionary by lexicographic order and split all the variables
        dictionary_list = sorted(dictionary.items(), key = lambda x:x[0])
        for entry in dictionary_list:
            self.classes.append(entry[0])
            self.pi.append(entry[1][0])
            self.mu.append(entry[1][1])

        #Compute covariance matrix
        self.cov_matrix = np.cov(X,rowvar=False)

        return self

    def predict(self, X):
        """Predict class for X.

        Parameters
        ----------
        X : array-like of shape = [n_samples, n_features]
            The input samples.

        Returns
        -------
        y : array of shape = [n_samples]
            The predicted classes, or the predict values.
        """

        probabilities = self.predict_proba(X)
        y = np.zeros(np.asarray(X).shape[0])
        for i, x in enumerate(X, 0):
            y[i] = self.classes[np.argmax(probabilities[i])]
        return y
        

    def predict_proba(self, X):
        """Return probability estimates for the test data X.

        Parameters
        ----------
        X : array-like of shape = [n_samples, n_features]
            The input samples.

        Returns
        -------
        p : array of shape = [n_samples, n_classes]
            The class probabilities of the input samples. Classes are ordered
            by lexicographic order.
        """

        probabilities = np.zeros([np.asarray(X).shape[0], np.asarray(self.classes).shape[0]])

        for i, x in enumerate(X, 0):
            for j, k in enumerate(self.classes, 0):
                sum_f = 0
                for l in self.classes:
                    sum_f += self.density_gauss(self.classes.index(l), x) * self.pi[self.classes.index(l)]
                probabilities[i,j] = self.density_gauss(self.classes.index(k), x) * self.pi[self.classes.index(l)] / sum_f

        
        return probabilities

    def density_gauss(self, k, x):
        """Return probability density for the test sample x belonging to the class k.

        Parameters
        ----------
        x : array-like of shape = [n_features]
            The input sample.
        k : int
            Class

        Returns
        -------
        f_k(x) : int
                 Probability density that x belongs to the class k
        """

        return np.divide(np.exp(-1/2*(x-self.mu[self.classes.index(k)])@np.linalg.inv(self.cov_matrix)@(x-self.mu[self.classes.index(k)]).T), 
                         np.power(2*np.pi,x.ndim/2)*np.sqrt(np.linalg.det(self.cov_matrix)))



def make_lda(nbSamples = 1500, fname = "", graph = True, data = 2):
    if data == 1:
        X,y = make_dataset1(nbSamples)
    else:
        X,y = make_dataset2(nbSamples)
    X_ls, X_ts, y_ls, y_ts = train_test_split(X, y, train_size =.8, test_size = .2)
    estimator = LinearDiscriminantAnalysis().fit(X_ls, y_ls)
    y_pred = estimator.predict(X_ts)
    if graph:
        plot_boundary(fname,estimator, X,y)
    return accuracy_score(y_ts, y_pred)


if __name__ == "__main__":

    max_iteration = 5
    #dataset 2
    score = []

    make_lda(fname ="lda2")

    for i in range(max_iteration):
        score.append(make_lda(graph = False))
    print("Dataset 2 : average accuracy "+ str(np.mean(score)) +", standard deviation : " + str(np.std(score)))
    score[:] = []

    #dataset 1
    make_lda(fname ="lda1", data = 1)

    for i in range(max_iteration):
        score.append(make_lda(graph = False))
    print("Dataset 1 : average accuracy "+ str(np.mean(score)) +", standard deviation : " + str(np.std(score)))




    
